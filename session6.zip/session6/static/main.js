const url = "http://127.0.0.1:8000";
const cards = document.querySelector(".cards");

async function getName(name) {
    const response = await fetch(url + `/${name}`, {
        method: "GET",
    });
    const student = await response.json();
    console.log(student);
    cards.innerHTML = ""
    let students = `<div class="card"> 
       <h2>id = ${student[0]}</h2>
       <h1>name = ${student[1]}</h1>
       <h3>age = ${student[2]}</h3> `
        cards.innerHTML += students;
}

async function allStudents() {
    const response = await fetch(url + "/students", {
        method: "GET",
    });
    const data = await response.json();
    console.log(data);
    cards.innerHTML = ""
    for (let std of data) {
    let students = `<div class="card"> 
       <h2>id = ${std[0]}</h2>
       <h1>name = ${std[1]}</h1>
    <button onclick="getName('${std[1]}')">More</button>
    </div>`
    cards.innerHTML += students;
    }
}


